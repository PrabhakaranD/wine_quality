Open Project folder

Create new conda environment 
    File -> Settings -> Project: <Project Name> -> Project Interpreter
    Python 3.7
    Apply, OK

Create requirements.txt

Install the requirements
    --bash
    pip install -r requirements.txt

Download data from https://www.youtube.com/redirect?event=live_chat&redir_token=QUFFLUhqbVQ3dVFfaWVfN19xTklhb1lyT0YzaEhsbmNyZ3xBQ3Jtc0tsR3pLN1VSdTZzdEw5SWhzcWd4T0ZSdEY5Y2ZDbGNaMUdHaFVGYmFyWXRDOGZXNG9aa3NLTW51WDdkVzRKb2Uyb3RnWEh6Y0dBV0FUOUdGMHhKX1dBT0hyaVBBWmJVM2lEZTdJVV9iS1htRFRCVHRGUQ&q=https%3A%2F%2Fdrive.google.com%2Fdrive%2Ffolders%2F18zqQiCJVgF7uzXgfbIJ-04zgz1ItNfF5%3Fusp%3Dsharing

git init

dvc init

dvc add data_given/winequality.csv

git add .

git commit -m "first commit"

git add . && git commit -m "update Readme.md"

git remote add origin https://github.com/PrabhakaranD/wine_quality.git
git branch -M main
git push -u origin main